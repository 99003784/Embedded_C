// MCU SPECIFIC HEADER FILE
#include<stdio.h>

//#include "Stm32f4xx_gpio_driver.h"
// GENERAL MACROS
#define __vo volatile
#define ENABLE  1
#define DISABLE 0
#define SET     1
#define RESET   0

// MACROS FOR DIFFERENT MEMORIES

#define SRAM1 0x20000000U
#define SRAM2 0x2001C000U
#define Flash 0x08000000U
#define ROM 0x1FFF0000U

// MACROS FOR BUS SYSTEM

#define BUS_BASEADDR 0x40000000U
#define APB1_BASEADDR 0x40000000U
#define APB2_BASEADDR 0x40010000U
#define AHB1_BASEADDR 0x40020000U
#define AHB2_BASEADDR 0x50000000U

// MACROS FOR GPIOS

#define GPIOA_BASADDR (AHB1_BASEADDR + 0x00)
#define GPIOB_BASADDR (AHB1_BASEADDR + 0x0400)
#define GPIOC_BASADDR (AHB1_BASEADDR + 0x0800)
#define GPIOD_BASADDR (AHB1_BASEADDR + 0x0C00)
#define GPIOE_BASADDR (AHB1_BASEADDR + 0x1000)
#define GPIOF_BASADDR (AHB1_BASEADDR + 0x1400)
#define GPIOG_BASADDR (AHB1_BASEADDR + 0x1800)
#define GPIOH_BASADDR (AHB1_BASEADDR + 0x1C00)
#define GPIOI_BASADDR (AHB1_BASEADDR + 0x2000)
#define GPIOJ_BASADDR (AHB1_BASEADDR + 0x2400)
#define GPIOK_BASADDR (AHB1_BASEADDR + 0x2800)

// MACROS FOR GPIO POINTER STRUCTURE

#define GPIOA (GPIO_RegDef_t*)GPIOA_BASADDR
#define GPIOB (GPIO_RegDef_t*)GPIOB_BASADDR
#define GPIOC (GPIO_RegDef_t*)GPIOC_BASADDR
#define GPIOD (GPIO_RegDef_t*)GPIOD_BASADDR
#define GPIOE (GPIO_RegDef_t*)GPIOE_BASADDR
#define GPIOF (GPIO_RegDef_t*)GPIOF_BASADDR
#define GPIOG (GPIO_RegDef_t*)GPIOG_BASADDR
#define GPIOH (GPIO_RegDef_t*)GPIOH_BASADDR
#define GPIOI (GPIO_RegDef_t*)GPIOI_BASADDR
#define GPIOJ (GPIO_RegDef_t*)GPIOJ_BASADDR
#define GPIOK (GPIO_RegDef_t*)GPIOK_BASADDR

// MACROS FOR PERIPHERAL HANGING ONTO APB BUS

#define TIM2_BASE_ADDR (APB1_BASE_ADDR+0x00)
#define TIM3_BASE_ADDR (APB1_BASE_ADDR+0x0400)
#define TIM4_BASE_ADDR (APB1_BASE_ADDR+0x0800)
#define TIM5_BASE_ADDR (APB1_BASE_ADDR+0x0C00)
#define TIM6_BASE_ADDR (APB1_BASE_ADDR+0x1000)
#define TIM7_BASE_ADDR (APB1_BASE_ADDR+0x1400)
#define TIM12_BASE_ADDR (APB1_BASE_ADDR+0x1800)
#define TIM13_BASE_ADDR (APB1_BASE_ADDR+0x1c00)
#define TIM14_BASE_ADDR (APB1_BASE_ADDR+0x2000)

#define DAC_BASEADDR (APB1_BASEADDR + 0x7400)
#define PWR_BASEADDR (APB1_BASEADDR + 0x7000)
#define CAN2_BASEADDR (APB1_BASEADDR + 0x6800)
#define CAN1_BASEADDR (APB1_BASEADDR + 0x6400)
#define I2C3_BASEADDR (APB1_BASEADDR + 0x5C00)
#define I2C2_BASEADDR (APB1_BASEADDR + 0x5800)
#define I2C1_BASEADDR (APB1_BASEADDR + 0x5400)
#define UART5_BASEADDR (APB1_BASEADDR + 0x5000)
#define UART4_BASEADDR (APB1_BASEADDR + 0x4C00)
#define USART3_BASEADDR (APB1_BASEADDR + 0x4800)
#define USART2_BASEADDR (APB1_BASEADDR + 0x4400)

#define RTC_BKP_BASE_ADDR (APB1_BASE_ADDR + 0x28)
#define WWDG_BASE_ADDR (APB1_BASE_ADDR + 0x2C)
#define IWDG_BASE_ADDR (APB1_BASE_ADDR + 0x30)
#define I2S2EXT_BASE_ADDR (APB1_BASE_ADDR + 0x34)
#define SPI2_BASE_ADDR (APB1_BASE_ADDR + 0x38)
#define SPI3_BASE_ADDR (APB1_BASE_ADDR + 0x3C)

#define TIM1_BASE_ADDR (APB2_BASE_ADDR + 0x0000)
#define TIM8_BASE_ADDR (APB2_BASE_ADDR + 0x0400)
#define USART1_BASE_ADDR (APB2_BASE_ADDR + 0x1000)
#define USART6_BASE_ADDR (APB2_BASE_ADDR + 0x1400)
#define ADC_BASE_ADDR (APB2_BASE_ADDR + 0x2000)
#define SDIO_BASE_ADDR (APB2_BASE_ADDR + 0x2C00)
#define SPI1_BASE_ADDR (APB2_BASE_ADDR + 0x3000)
#define SPI4_BASE_ADDR (APB2_BASE_ADDR + 0x3400)
#define SYSCFG_BASE_ADDR (APB2_BASE_ADDR + 0x3800)
#define EXTI_BASE_ADDR (APB2_BASE_ADDR + 0x3C00)
#define TIM9_BASE_ADDR (APB2_BASE_ADDR + 0x4000)
#define TIM10_BASE_ADDR (APB2_BASE_ADDR + 0x4400)
#define TIME11_BASE_ADDR (APB2_BASE_ADDR + 0x4800)
#define SPI5_BASE_ADDR (APB2_BASE_ADDR + 0x5000)
#define SPI6_BASE_ADDR (APB2_BASE_ADDR + 0x5400)
#define SAI1_BASE_ADDR (APB2_BASE_ADDR + 0x5800)
#define LCD_TFT_BASE_ADDR (APB2_BASE_ADDR + 0x6800)


//#define RCC ((RCC_RegDef_t*)BASE_MEM_RCC)  // 0x40023800
//#define RCC_BASE_ADDR (AHB1_BASEADDR+ 0x3800)
#define RCC ((RCC_RegDef_t*)RCC_BASE_ADDR)
#define RCC_BASE_ADDR  (AHB1_BASEADDR+ 0x3800)

// GPIO REGISTER DEFINITIONS
typedef struct
{
 volatile uint32_t MODER; //+00 offset
 volatile uint32_t OTYPER;//+04 offset
 volatile uint32_t OSPEEDR;//+08 offset
 volatile uint32_t PURDR;//+0C offset
 volatile uint32_t IDR;//+10 offset
 volatile uint32_t ODR;//+14 offset
 volatile uint32_t BSRR;//+18 offset
 volatile uint32_t LCKR;//+1C offset
 volatile uint32_t AFR[2];//+20 offset
}GPIO_RegDef_t;

// RCC REGISTER DEFINITIONS
typedef struct
{
	 __vo uint32_t CR;            /*!< TODO,     										Address offset: 0x00 */
	  __vo uint32_t PLLCFGR;       /*!< TODO,     										Address offset: 0x04 */
	  __vo uint32_t CFGR;          /*!< TODO,     										Address offset: 0x08 */
	  __vo uint32_t CIR;           /*!< TODO,     										Address offset: 0x0C */
	  __vo uint32_t AHB1RSTR;      /*!< TODO,     										Address offset: 0x10 */
	  __vo uint32_t AHB2RSTR;      /*!< TODO,     										Address offset: 0x14 */
	  __vo uint32_t AHB3RSTR;      /*!< TODO,     										Address offset: 0x18 */
	  uint32_t      RESERVED0;     /*!< Reserved, 0x1C                                                       */
	  __vo uint32_t APB1RSTR;      /*!< TODO,     										Address offset: 0x20 */
	  __vo uint32_t APB2RSTR;      /*!< TODO,     										Address offset: 0x24 */
	  uint32_t      RESERVED1[2];  /*!< Reserved, 0x28-0x2C                                                  */
	  __vo uint32_t AHB1ENR;       /*!< TODO,     										Address offset: 0x30 */
	  __vo uint32_t AHB2ENR;       /*!< TODO,     										Address offset: 0x34 */
	  __vo uint32_t AHB3ENR;       /*!< TODO,     										Address offset: 0x38 */
	  uint32_t      RESERVED2;     /*!< Reserved, 0x3C                                                       */
	  __vo uint32_t APB1ENR;       /*!< TODO,     										Address offset: 0x40 */
	  __vo uint32_t APB2ENR;       /*!< TODO,     										Address offset: 0x44 */
	  uint32_t      RESERVED3[2];  /*!< Reserved, 0x48-0x4C                                                  */
	  __vo uint32_t AHB1LPENR;     /*!< TODO,     										Address offset: 0x50 */
	  __vo uint32_t AHB2LPENR;     /*!< TODO,     										Address offset: 0x54 */
	  __vo uint32_t AHB3LPENR;     /*!< TODO,     										Address offset: 0x58 */
	  uint32_t      RESERVED4;     /*!< Reserved, 0x5C                                                       */
	  __vo uint32_t APB1LPENR;     /*!< TODO,     										Address offset: 0x60 */
	  __vo uint32_t APB2LPENR;     /*!< RTODO,     										Address offset: 0x64 */
	  uint32_t      RESERVED5[2];  /*!< Reserved, 0x68-0x6C                                                  */
	  __vo uint32_t BDCR;          /*!< TODO,     										Address offset: 0x70 */
	  __vo uint32_t CSR;           /*!< TODO,     										Address offset: 0x74 */
	  uint32_t      RESERVED6[2];  /*!< Reserved, 0x78-0x7C                                                  */
	  __vo uint32_t SSCGR;         /*!< TODO,     										Address offset: 0x80 */
	  __vo uint32_t PLLI2SCFGR;    /*!< TODO,     										Address offset: 0x84 */
	  __vo uint32_t PLLSAICFGR;    /*!< TODO,     										Address offset: 0x88 */
	  __vo uint32_t DCKCFGR;       /*!< TODO,     										Address offset: 0x8C */
	  __vo uint32_t CKGATENR;      /*!< TODO,     										Address offset: 0x90 */
	  __vo uint32_t DCKCFGR2;      /*!< TODO,     										Address offset: 0x94 */

}RCC_RegDef_t;








// Macros for enabling the clock for GPIOS
# define GPIOA_PCLOCK_ENABLE (RCC->AHB1ENR = (1<<0))
# define GPIOB_PCLOCK_ENABLE (RCC->AHB1ENR = (1<<1))
# define GPIOC_PCLOCK_ENABLE (RCC->AHB1ENR = (1<<2))
# define GPIOD_PCLOCK_ENABLE (RCC->AHB1ENR = (1<<3))
# define GPIOE_PCLOCK_ENABLE (RCC->AHB1ENR = (1<<4))
# define GPIOH_PCLOCK_ENABLE (RCC->AHB1ENR = (1<<7))



//Macros for disabling the clock for GPIOS
# define GPIOA_PCLOCK_DISABLE (RCC->AHB1ENR = ~(1<<0))
# define GPIOB_PCLOCK_DISABLE (RCC->AHB1ENR = ~(1<<1))
# define GPIOC_PCLOCK_DISABLE (RCC->AHB1ENR = ~(1<<2))
# define GPIOD_PCLOCK_DISABLE (RCC->AHB1ENR = ~(1<<3))
# define GPIOE_PCLOCK_DISABLE (RCC->AHB1ENR = ~(1<<4))
# define GPIOH_PCLOCK_DISABLE (RCC->AHB1ENR = ~(1<<7))


#define GPIOA_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 0)); (RCC->AHB1RSTR &= ~(1 << 0)); }while(0)
#define GPIOB_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 1)); (RCC->AHB1RSTR &= ~(1 << 1)); }while(0)
#define GPIOC_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 2)); (RCC->AHB1RSTR &= ~(1 << 2)); }while(0)
#define GPIOD_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 3)); (RCC->AHB1RSTR &= ~(1 << 3)); }while(0)
#define GPIOE_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 4)); (RCC->AHB1RSTR &= ~(1 << 4)); }while(0)
#define GPIOF_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 5)); (RCC->AHB1RSTR &= ~(1 << 5)); }while(0)
#define GPIOG_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 6)); (RCC->AHB1RSTR &= ~(1 << 6)); }while(0)
#define GPIOH_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 7)); (RCC->AHB1RSTR &= ~(1 << 7)); }while(0)
#define GPIOI_REG_RESET()               do{ (RCC->AHB1RSTR |= (1 << 8)); (RCC->AHB1RSTR &= ~(1 << 8)); }while(0)


