/*
 * stm32fxx_gpio_driver.h
 *
 *  Created on: Mar 5, 2021
 *      Author: 99003784
 */

#ifndef INC_STM32F4XX_GPIO_DRIVER_H_
#define INC_STM32F4XX_GPIO_DRIVER_H_

#include "Stm32f4xx.h"



typedef struct
{
	uint8_t GPIO_Pin_Numb;
	uint8_t GPIO_PIN_MODE;
	uint8_t GPIO_Speed;
	uint8_t GPIO_OTYPE; // output type
	uint8_t GPIO_PUPD; // pull up or pull down
	uint8_t GPIO_AFN; // Alternate function
}GPIO_PinConfig;

// Creating handle structure

typedef struct
{
   GPIO_RegDef_t *pGPIOx; // Declared a pointer variable of GPIO_RegDef
   GPIO_PinConfig pin_config; // Declaring the variable for pin configuration of the structure type GPIO_pin_config
}GPIO_Handle_t;

// Creating the structure for GPIO_PinConfig


// Creating API Prototype
// I. Peripheral clock enable or disable

void GPIO_PeripheralClk(GPIO_RegDef_t *pGPIOx,uint8_t ENorDI);


// II. Initialize and Dinitialize

void GPIO_Ini(GPIO_Handle_t *pGPIO_Handle_t);
void GPIO_DInit(GPIO_RegDef_t *pGPIOx);

// III. Read/Write to/from ports/pins

uint16_t GPIO_ReadfromPort(GPIO_RegDef_t *pGPIOx);
uint8_t GPIO_ReadfromPin(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum);
void GPIO_WritetoPort(GPIO_RegDef_t *pGPIOx, uint16_t value);
void GPIO_WritetoPin(GPIO_RegDef_t *pGPIOX, uint8_t GPIO_PinNum, uint16_t value);
void GPIO_Toggle(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum);

// Defining macros for Pin Number

#define GPIO_Pin_Numb_0     0
#define GPIO_Pin_Numb_1     1
#define GPIO_Pin_Numb_2     2
#define GPIO_Pin_Numb_3     3
#define GPIO_Pin_Numb_4     4
#define GPIO_Pin_Numb_5     5
#define GPIO_Pin_Numb_6     6
#define GPIO_Pin_Numb_7     7
#define GPIO_Pin_Numb_8     8
#define GPIO_Pin_Numb_9     9
#define GPIO_Pin_Numb_10   10
#define GPIO_Pin_Numb_11   11
#define GPIO_Pin_Numb_12   12
#define GPIO_Pin_Numb_13   13
#define GPIO_Pin_Numb_14   14
#define GPIO_Pin_Numb_15   15

//Defining for GPIO_PinMode


#define GPIO_PIN_MODE_IN 0
#define GPIO_PIN_MODE_OUT 1
#define GPIO_PIN_MODE_AFN 2
#define GPIO_PIN_MODE_ANALOG 3

//Defining macros for GPIO_Speed


#define GPIO_Speed_LOW 0
#define GPIO_Speed_MEDIUM 1
#define GPIO_Speed_FAST 2
#define GPIO_Speed_HIGH 3



//Defining macros for GPIO_Output type


#define GPIO_OTYPE_PP 0
#define GPIO_OTYPE_OD 1



//Defining macros for GPIO_PuPD


#define GPIO_PUPD_NoPUPD 0
#define GPIO_PUPD_PU 1
#define GPIO_PUPD_PD 2

// Defining for GPIO_AltFn

#define GPIO_AFN_0 0
#define GPIO_AFN_1 1
#define GPIO_AFN_2 2
#define GPIO_AFN_3 3
#define GPIO_AFN_4 4
#define GPIO_AFN_5 5
#define GPIO_AFN_6 6
#define GPIO_AFN_7 7
#define GPIO_AFN_8 8
#define GPIO_AFN_9 9
#define GPIO_AFN_10 10
#define GPIO_AFN_11 11
#define GPIO_AFN_12 12
#define GPIO_AFN_13 13
#define GPIO_AFN_14 14
#define GPIO_AFN_15 15

#endif /* INC_STM32F4XX_GPIO_DRIVER_H_ */

