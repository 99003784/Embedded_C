/*
 * stm32f4xx_gpio_driver.c
 *
 *  Created on: Mar 5, 2021
 *      Author: 99003784
 */


#include "Stm32f4xx_gpio_driver.h"


// Creating API Prototype
// I. Peripheral clock enable or disable

void GPIO_PeripheralClk(GPIO_RegDef_t *pGPIOx,uint8_t ENorDI)
{
	if(ENorDI == ENABLE)
	{
		if (pGPIOx == GPIOA)
		{
			GPIOA_PCLOCK_ENABLE;
		}
		else if (pGPIOx == GPIOB)
		{
			GPIOB_PCLOCK_ENABLE;
		}
		else if (pGPIOx == GPIOC)
		{
			GPIOC_PCLOCK_ENABLE;
		}
		else if (pGPIOx == GPIOD)
				{
					GPIOD_PCLOCK_ENABLE;
				}
		else if (pGPIOx == GPIOE)
				{
					GPIOE_PCLOCK_ENABLE;
				}
		else if (pGPIOx == GPIOH)
				{
					GPIOH_PCLOCK_ENABLE;
				}
	}
	else
	    {
	        if(pGPIOx == GPIOA)
	        {
	            GPIOA_PCLOCK_DISABLE;
	        }
	        else if(pGPIOx == GPIOB)
	        {
	            GPIOB_PCLOCK_DISABLE;
	        }
	        else if(pGPIOx == GPIOC)
	        {
	            GPIOC_PCLOCK_DISABLE;
	        }
	        else if(pGPIOx == GPIOD)
	        {
	            GPIOD_PCLOCK_DISABLE;
	        }
	        else if(pGPIOx == GPIOE)
	        {
	            GPIOE_PCLOCK_DISABLE;
	        }
	        else
	        {
	            GPIOH_PCLOCK_DISABLE;
	        }



	    }
}

// II. Initialize and Dinitialize

void GPIO_Ini(GPIO_Handle_t *pGPIO_Handle_t)
{
	//1. Config pin mode
	uint32_t temp;
	temp=(pGPIO_Handle_t ->pin_config.GPIO_PIN_MODE) << (2*pGPIO_Handle_t->pin_config.GPIO_PIN_MODE);
	pGPIO_Handle_t -> pGPIOx->MODER =~(0x3) << (2*pGPIO_Handle_t->pin_config.GPIO_Pin_Numb);
	pGPIO_Handle_t -> pGPIOx->MODER = temp;

	// 2. config pin OTYPER
	uint16_t dummy;
	dummy = (pGPIO_Handle_t ->pin_config.GPIO_OTYPE) << (pGPIO_Handle_t->pin_config.GPIO_Pin_Numb);
	pGPIO_Handle_t ->pGPIOx->OTYPER = ~(0x1) << (pGPIO_Handle_t->pin_config.GPIO_Pin_Numb);
	pGPIO_Handle_t ->pGPIOx->OTYPER = dummy;

	//3. Config O_speed
	uint32_t result;
	result = (pGPIO_Handle_t ->pin_config.GPIO_Speed) << (2*pGPIO_Handle_t->pin_config.GPIO_Pin_Numb);
	pGPIO_Handle_t ->pGPIOx->OSPEEDR = ~(0x3) << (2*pGPIO_Handle_t->pin_config.GPIO_Pin_Numb);
	pGPIO_Handle_t ->pGPIOx->OSPEEDR = result;

	//4. Config PUPD
	uint32_t result1;
	result1 = (pGPIO_Handle_t ->pin_config.GPIO_PUPD) << (2*pGPIO_Handle_t->pin_config.GPIO_Pin_Numb);
	pGPIO_Handle_t ->pGPIOx->PURDR = ~(0x3) << (2*pGPIO_Handle_t->pin_config.GPIO_Pin_Numb);
	pGPIO_Handle_t->pGPIOx->PURDR = result1;

	// Config Alt fxn
	uint8_t temp1;
	uint8_t temp2;
	temp1 = pGPIO_Handle_t ->pin_config.GPIO_Pin_Numb / 8;
	temp2 = pGPIO_Handle_t ->pin_config.GPIO_Pin_Numb % 8;



	pGPIO_Handle_t -> pGPIOx->AFR[temp1] &= ~(0xF << (4 * temp2));
	pGPIO_Handle_t -> pGPIOx->AFR[temp1] |= pGPIO_Handle_t -> pin_config.GPIO_AFN << (4*temp2);

}



//3. Config

//4. Config PUPD

//5. Config IDR



void GPIO_DInit(GPIO_RegDef_t *pGPIOx);


// III. Read/Write to/from ports/pins

uint16_t GPIO_ReadfromPort(GPIO_RegDef_t *pGPIOx)
{
	uint16_t temp;
	temp = (uint16_t)(pGPIOx -> IDR);
	return temp;
	//GPIO_RegDef_t A;

}
uint8_t GPIO_ReadfromPin(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_Pin_Numb)
{
	uint8_t temp=0;
	temp=(uint8_t)(pGPIOx -> IDR >> GPIO_Pin_Numb & 0x00000001);
	return temp;
}

void GPIO_WritetoPort(GPIO_RegDef_t *pGPIOx, uint16_t value)
{
	pGPIOx-> ODR = value;
}
void GPIO_WritetoPin(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_Pin_Numb, uint16_t value)
{
   if(value==SET)
   {
	   pGPIOx -> ODR |=(1<<GPIO_Pin_Numb);
   }
   else
   {
	   pGPIOx -> ODR &=~(1<<GPIO_Pin_Numb);
   }
}

	void GPIO_Toggle(GPIO_RegDef_t *pGPIOx,uint8_t GPIO_Pin_Numb)
	{
	    pGPIOx ->ODR ^= (1<<GPIO_Pin_Numb);
	}

