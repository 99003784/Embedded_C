/*
 * led_blink.c
 *
 *  Created on: Mar 5, 2021
 *      Author: 99003784
 */
//#include"stm32f4xx.h"
#include"stm32f4xx_gpio_driver.h"

void delay(void)
{
	for(uint32_t i=0;i<5000;i++);

}
int main(void)
{
	GPIO_Handle_t GPIOLed;
	GPIOLed.pGPIOx = GPIOD;
	GPIOLed.pin_config.GPIO_Pin_Numb=  GPIO_Pin_Numb_12;
	GPIOLed.pin_config.GPIO_PIN_MODE= GPIO_PIN_MODE_OUT;
	GPIOLed.pin_config.GPIO_Speed=GPIO_Speed_FAST;
	GPIOLed.pin_config.GPIO_OTYPE=GPIO_OTYPE_PP;
	GPIOLed.pin_config.GPIO_PUPD=GPIO_PUPD_PU;
	GPIO_PeripheralClk(GPIOD, ENABLE);
	GPIO_Ini(&GPIOLed);

	while(1)
	{
		GPIO_Toggle(GPIOD, GPIO_Pin_Numb_12);
		delay();
	}

}
